package com.dev.frontend.panels;

public interface HasBusinessPresenter 
{
	BusinessPresenter getBusinessPresenter();
}
