README 

1. Sale application that has front end build using Swing
2. The backend is a war that needs to be deployed to apache tomcat server.
3. Make sure you have the mysql server up an running with the correct credentials.
4. Double click on the jar file in folder sales-app/frontend/targets/frontend.jar to begin

